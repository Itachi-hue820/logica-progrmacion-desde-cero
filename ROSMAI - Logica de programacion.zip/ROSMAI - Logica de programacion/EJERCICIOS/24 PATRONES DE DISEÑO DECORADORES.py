# EJERCICIO:
# Explora el concepto de "decorador" y muestra cómo crearlo
# con un ejemplo genérico.

# DIFICULTAD EXTRA (opcional):
# Crea un decorador que sea capaz de contabilizar cuántas veces
# se ha llamado a una función y aplícalo a una función de tu elección.

# Mi codigo.