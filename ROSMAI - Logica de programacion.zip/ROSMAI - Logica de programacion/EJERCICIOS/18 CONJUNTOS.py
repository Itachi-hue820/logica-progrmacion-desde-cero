# EJERCICIO:
# Utilizando tu lenguaje crea un conjunto de datos y realiza las siguientes
# operaciones (debes utilizar una estructura que las soporte):
# - Añade un elemento al final.
# - Añade un elemento al principio.
# - Añade varios elementos en bloque al final.
# - Añade varios elementos en bloque en una posición concreta.
# - Elimina un elemento en una posición concreta.
# - Actualiza el valor de un elemento en una posición concreta.
# - Comprueba si un elemento está en un conjunto.
# - Elimina todo el contenido del conjunto.

# DIFICULTAD EXTRA (opcional):
# Muestra ejemplos de las siguientes operaciones con conjuntos:
# - Unión.
# - Intersección.
# - Diferencia.
# - Diferencia simétrica.

# Mi codigo.