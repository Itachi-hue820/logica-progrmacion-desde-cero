def countdown(): # Ayuda de chatgpt con lo de dejarlo sin nada dentro.
     for number in range(10, 56):
          if number % 3 != 0 and number != 16 and number % 2 != 0: 
            print(number)
            
countdown() # Ayuda de chatgpt.